$(document).ready(function(){
    AOS.init({
        once: true, 
    });
});
